﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using HighCard;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HighCard.Tests
{
    [TestClass()]
    public class DeckTests
    {
        private readonly Deck gameDeck = new();

        [TestMethod()]
        public void BuildDeckTestCorrect()
        {
            List<Card> tempTestDeck = BuildOrderedDeck();
            gameDeck.BuildDeck();
            List<Card> tempGameDeck = gameDeck.getOrderedDeck();

            CollectionAssert.AreEqual(tempTestDeck, tempGameDeck, "The game deck has missing/incorrect cards.");
        }

        [TestMethod()]
        public void CompleteDeckShuffleTest()
        {
            List<Card> tempTestDeck = BuildOrderedDeck();
            gameDeck.BuildDeck();
            gameDeck.Shuffle();
            Stack<Card> tempGameDeck = gameDeck.getGameDeck();

            CollectionAssert.AreEquivalent(tempTestDeck, tempGameDeck, "The game deck has missing/incorrect cards.");
        }

        [TestMethod()]
        public void DeckHasBeenShuffledTest()
        {
            List<Card> tempTestDeck = BuildOrderedDeck();
            gameDeck.BuildDeck();
            gameDeck.Shuffle();
            Stack<Card> tempGameDeck = gameDeck.getGameDeck();

            CollectionAssert.AreNotEqual(tempTestDeck, tempGameDeck, "The game deck has not been shuffled.");
        }

        public List<Card> BuildOrderedDeck()
        {
            List<Card> baseOrderedDeck = new ();
            baseOrderedDeck.Add(new FaceCard() { Suit = Suit.Spades, Value = 1 });
            baseOrderedDeck.Add(new SuitCard() { Suit = Suit.Spades, Value = 2 });
            baseOrderedDeck.Add(new SuitCard() { Suit = Suit.Spades, Value = 3 });
            baseOrderedDeck.Add(new SuitCard() { Suit = Suit.Spades, Value = 4 });
            baseOrderedDeck.Add(new SuitCard() { Suit = Suit.Spades, Value = 5 });
            baseOrderedDeck.Add(new SuitCard() { Suit = Suit.Spades, Value = 6 });
            baseOrderedDeck.Add(new SuitCard() { Suit = Suit.Spades, Value = 7 });
            baseOrderedDeck.Add(new SuitCard() { Suit = Suit.Spades, Value = 8 });
            baseOrderedDeck.Add(new SuitCard() { Suit = Suit.Spades, Value = 9 });
            baseOrderedDeck.Add(new SuitCard() { Suit = Suit.Spades, Value = 10 });
            baseOrderedDeck.Add(new FaceCard() { Suit = Suit.Spades, Value = 11 });
            baseOrderedDeck.Add(new FaceCard() { Suit = Suit.Spades, Value = 12 });
            baseOrderedDeck.Add(new FaceCard() { Suit = Suit.Spades, Value = 13 });
            baseOrderedDeck.Add(new FaceCard() { Suit = Suit.Clubs, Value = 1 });
            baseOrderedDeck.Add(new SuitCard() { Suit = Suit.Clubs, Value = 2 });
            baseOrderedDeck.Add(new SuitCard() { Suit = Suit.Clubs, Value = 3 });
            baseOrderedDeck.Add(new SuitCard() { Suit = Suit.Clubs, Value = 4 });
            baseOrderedDeck.Add(new SuitCard() { Suit = Suit.Clubs, Value = 5 });
            baseOrderedDeck.Add(new SuitCard() { Suit = Suit.Clubs, Value = 6 });
            baseOrderedDeck.Add(new SuitCard() { Suit = Suit.Clubs, Value = 7 });
            baseOrderedDeck.Add(new SuitCard() { Suit = Suit.Clubs, Value = 8 });
            baseOrderedDeck.Add(new SuitCard() { Suit = Suit.Clubs, Value = 9 });
            baseOrderedDeck.Add(new SuitCard() { Suit = Suit.Clubs, Value = 10 });
            baseOrderedDeck.Add(new FaceCard() { Suit = Suit.Clubs, Value = 11 });
            baseOrderedDeck.Add(new FaceCard() { Suit = Suit.Clubs, Value = 12 });
            baseOrderedDeck.Add(new FaceCard() { Suit = Suit.Clubs, Value = 13 });
            baseOrderedDeck.Add(new FaceCard() { Suit = Suit.Hearts, Value = 1 });
            baseOrderedDeck.Add(new SuitCard() { Suit = Suit.Hearts, Value = 2 });
            baseOrderedDeck.Add(new SuitCard() { Suit = Suit.Hearts, Value = 3 });
            baseOrderedDeck.Add(new SuitCard() { Suit = Suit.Hearts, Value = 4 });
            baseOrderedDeck.Add(new SuitCard() { Suit = Suit.Hearts, Value = 5 });
            baseOrderedDeck.Add(new SuitCard() { Suit = Suit.Hearts, Value = 6 });
            baseOrderedDeck.Add(new SuitCard() { Suit = Suit.Hearts, Value = 7 });
            baseOrderedDeck.Add(new SuitCard() { Suit = Suit.Hearts, Value = 8 });
            baseOrderedDeck.Add(new SuitCard() { Suit = Suit.Hearts, Value = 9 });
            baseOrderedDeck.Add(new SuitCard() { Suit = Suit.Hearts, Value = 10 });
            baseOrderedDeck.Add(new FaceCard() { Suit = Suit.Hearts, Value = 11 });
            baseOrderedDeck.Add(new FaceCard() { Suit = Suit.Hearts, Value = 12 });
            baseOrderedDeck.Add(new FaceCard() { Suit = Suit.Hearts, Value = 13 });
            baseOrderedDeck.Add(new FaceCard() { Suit = Suit.Diamonds, Value = 1 });
            baseOrderedDeck.Add(new SuitCard() { Suit = Suit.Diamonds, Value = 2 });
            baseOrderedDeck.Add(new SuitCard() { Suit = Suit.Diamonds, Value = 3 });
            baseOrderedDeck.Add(new SuitCard() { Suit = Suit.Diamonds, Value = 4 });
            baseOrderedDeck.Add(new SuitCard() { Suit = Suit.Diamonds, Value = 5 });
            baseOrderedDeck.Add(new SuitCard() { Suit = Suit.Diamonds, Value = 6 });
            baseOrderedDeck.Add(new SuitCard() { Suit = Suit.Diamonds, Value = 7 });
            baseOrderedDeck.Add(new SuitCard() { Suit = Suit.Diamonds, Value = 8 });
            baseOrderedDeck.Add(new SuitCard() { Suit = Suit.Diamonds, Value = 9 });
            baseOrderedDeck.Add(new SuitCard() { Suit = Suit.Diamonds, Value = 10 });
            baseOrderedDeck.Add(new FaceCard() { Suit = Suit.Diamonds, Value = 11 });
            baseOrderedDeck.Add(new FaceCard() { Suit = Suit.Diamonds, Value = 12 });
            baseOrderedDeck.Add(new FaceCard() { Suit = Suit.Diamonds, Value = 13 });
            baseOrderedDeck.Add(new WildCard() { Value = 14 });
            baseOrderedDeck.Add(new WildCard() { Value = 14 });
            return baseOrderedDeck;
        }
    }
}