﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using HighCard;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HighCard.Tests
{
    [TestClass()]
    public class GameTests
    {
        [TestMethod()]
        public void DrawTest()
        {
            int playersCardValue = 5;
            int dealersCardValue = 5;

            int roundWinner = Game.DetermineResult(playersCardValue, dealersCardValue);

            Assert.IsTrue(roundWinner == 3);
        }

        [TestMethod()]
        public void PlayerWinsTest()
        {
            int playersCardValue = 7;
            int dealersCardValue = 5;

            int roundWinner = Game.DetermineResult(playersCardValue, dealersCardValue);

            Assert.IsTrue(roundWinner == 1);
        }

        [TestMethod()]
        public void DealerWinsTest()
        {
            int playersCardValue = 5;
            int dealersCardValue = 7;

            int roundWinner = Game.DetermineResult(playersCardValue, dealersCardValue);

            Assert.IsTrue(roundWinner == 2);
        }
    }
}